package com.mybuddy.paymybudd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymybuddApplicationTests {

	@Test
	void contextLoads() {
	}

}
